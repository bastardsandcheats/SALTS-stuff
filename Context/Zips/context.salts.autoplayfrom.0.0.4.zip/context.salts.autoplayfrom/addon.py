import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import time

# Change this if it takes longer to scrape
timeout = 25

line = xbmcvfs.File(xbmc.getInfoLabel('ListItem.FileNameAndPath')).read()
if 'plugin.video.salts' in line:
    SALTS = xbmcaddon.Addon('plugin.video.salts')
    line = line.replace('mode=get_sources', 'mode=autoplay')
    epqul = 'Episode_quality'
    mvqul = 'Movie_quality'
    Quls = ('1080P just once', '720P just once', 
    'High just once', 'Medium just once', 'Low just once', '1080P always', '720P always', 'High always', 'Medium always', 'Low always')

    selqul = xbmcgui.Dialog().select('Autoplay starting from', Quls)
    if selqul > -1:
        if selqul < 5:
            curepqul = SALTS.getSetting(epqul)
            curmvqul = SALTS.getSetting(mvqul)
            SALTS.setSetting(epqul, ('%s' % selqul))
            SALTS.setSetting(mvqul, ('%s' % selqul))

            xbmc.executebuiltin('XBMC.Notification(SALTS trying autoplay ,Seting max quality to %s, 8000, )' % Quls[selqul])
            xbmc.executebuiltin('playmedia(%s)' % line)

            time.sleep(15)
            t = time.time()
            while time.time() <= t + timeout:
                if (xbmc.Player().isPlayingVideo()):
                    break
                else:
                    time.sleep(1)

            SALTS.setSetting(epqul, curepqul)
            SALTS.setSetting(mvqul, curmvqul)

        else:
            selqul -= 5
            SALTS.setSetting(epqul, ('%s' % selqul))
            SALTS.setSetting(mvqul, ('%s' % selqul))
            selqul += 5
            xbmc.executebuiltin('XBMC.Notification(SALTS trying autoplay ,Seting max quality to %s, 8000, )' % Quls[selqul])
            xbmc.executebuiltin('playmedia(%s)' % line)

    else:
        xbmc.executebuiltin('XBMC.Notification(User exited selection, , 2000, )')

else:
    xbmc.executebuiltin('XBMC.Notification(Not a salts library item, Can not play from here, 2000, )')
