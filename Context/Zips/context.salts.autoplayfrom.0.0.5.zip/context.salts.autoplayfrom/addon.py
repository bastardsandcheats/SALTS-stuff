import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import time

# Change this if it takes longer to scrape and autoplay
#  autoplaytime = 20  # average time in seconds until usable video is found
#  scrapetime = 20  # average time in seconds it takes you to scrape
# if no video is played in the combination of these two, max quality will
# be set back to normal
timeout = 40
tempfile = 'special://temp/context.salt.autoplayfrom.bac'

line = xbmcvfs.File(xbmc.getInfoLabel('ListItem.FileNameAndPath')).read()
if 'plugin.video.salts' in line:
    epqul = 'Episode_quality'
    mvqul = 'Movie_quality'
    SALTS = xbmcaddon.Addon('plugin.video.salts')

    if xbmcvfs.exists(tempfile):
        f = xbmcvfs.File(tempfile, 'r')
        backupqul = f.read()
        f.close()
        backupepqul, backupmvqul = backupqul.split()
        SALTS.setSetting(epqul, ('%s' % backupepqul))
        SALTS.setSetting(mvqul, ('%s' % backupmvqul))
        xbmcvfs.delete(tempfile)

    line = line.replace('mode=get_sources', 'mode=autoplay')
    Quls = (
            '1080P just once',
            '720P just once',
            'High just once',
            'Medium just once',
            'Low just once',
            '1080P always',
            '720P always',
            'High always',
            'Medium always',
            'Low always'
            )
    selqul = xbmcgui.Dialog().select('Autoplay starting from', Quls)
    if selqul > -1:
        if selqul < 5:
#            if (xbmc.Player().isPlayingVideo()):
#                xbmc.Player().stop()
            curepqul = SALTS.getSetting(epqul)
            curmvqul = SALTS.getSetting(mvqul)
            f = xbmcvfs.File(tempfile, 'w')
            f.write('%s %s' % (curepqul, curmvqul))
            f.close()
            SALTS.setSetting(epqul, ('%s' % selqul))
            SALTS.setSetting(mvqul, ('%s' % selqul))
            xbmc.executebuiltin('XBMC.Notification(SALTS trying autoplay,Seting max quality to %s, 5000,)' % Quls[selqul])
            xbmc.executebuiltin('playmedia(%s)' % line)
            time.sleep(40)

#            time.sleep(scrapetime)
#            t = time.time()
#            while time.time() <= t + autoplaytime:
#                if (xbmc.Player().isPlayingVideo()):
#                    break
#                else:
#                    time.sleep(1)

            SALTS.setSetting(epqul, curepqul)
            SALTS.setSetting(mvqul, curmvqul)
            xbmcvfs.delete(tempfile)

        else:
            selqul -= 5
            SALTS.setSetting(epqul, ('%s' % selqul))
            SALTS.setSetting(mvqul, ('%s' % selqul))
            selqul += 5
            xbmc.executebuiltin('XBMC.Notification(SALTS trying autoplay ,Seting max quality to %s, 5000, )' % Quls[selqul])
            xbmc.executebuiltin('playmedia(%s)' % line)

    else:
        xbmc.executebuiltin('XBMC.Notification(User exited selection, not changing anything, 1000, )')

else:
    xbmc.executebuiltin('XBMC.Notification(Not a salts library item, Can not play from here, 2000, )')
