import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import time

# Change this if it takes longer than 40 seconds to scrape
timeout = 40

line = xbmcvfs.File(xbmc.getInfoLabel('ListItem.FileNameAndPath')).read()
if 'plugin.video.salts' in line:
    SALTS = xbmcaddon.Addon('plugin.video.salts')
    line = line.replace('mode=get_sources', 'mode=autoplay')
    epqul = 'Episode_quality'
    mvqul = 'Movie_quality'
    Quls = ('1080P', '720P', 'High', 'Medium', 'Low')
    selqul = xbmcgui.Dialog().select('Autoplay starting from', Quls)
    if selqul > -1:
        curepqul = SALTS.getSetting(epqul)
        curmvqul = SALTS.getSetting(mvqul)
        SALTS.setSetting(epqul, ('%s' % selqul))
        SALTS.setSetting(mvqul, ('%s' % selqul))
        xbmc.executebuiltin('XBMC.Notification(SALTS trying autoplay ,Starting from %s, 8000, )' % Quls[selqul])
        xbmc.executebuiltin('playmedia(%s)' % line)

        time.sleep(5)
        t = time.time()
        while time.time() <= t + timeout:
            if (xbmc.Player().isPlayingVideo()):
                SALTS.setSetting(epqul, curepqul)
                SALTS.setSetting(mvqul, curmvqul)
                break
            else:
                time.sleep(2)
        SALTS.setSetting(epqul, curepqul)
        SALTS.setSetting(mvqul, curmvqul)
else:
    xbmc.executebuiltin('XBMC.Notification(Not a salts library item, Can not play from here, 2000, )')
